package globals

var (
	// Table   = make(map[string][]string, 0)
	UAS     = make([]string, 0)
	ACCEPTS = make([]string, 0)
	REFS    = make([]string, 0)
	PROXIES = make([]string, 0)
)
