# Cursed Objects
This script got it's name from **Jujutsu Kaisen**, yet I do not know why I did so. 

### Upcoming update
Into an new project called Cursed Spirits, the older one Cursed Objects will receive an power spike enhancement.

Cursed Spirit will be at least 10 times more powerful than Cursed Objects. It will be published into ``Pix4Devs/CursedSpirits``

Release: ``After 100 stars``
### Proofs
``Single machine 1 GBPS and public proxies``
<img src="https://media.discordapp.net/attachments/935123716617146369/1141780704460550195/image.png?width=1032&height=669">
<img src="https://media.discordapp.net/attachments/956310840464773200/1141694033572401273/image.png?width=1090&height=669" >
<img src="https://media.discordapp.net/attachments/956310840464773200/1141714985077182545/image-42.png">

### Disclaimer
By using this tool/script you automatically agree upon:

* The author is not responsable for any damage you may cause using this script/tool. 
* The user it self is responsable of any harm he/she/any object may cause.

> Made for educational purposes only, as self help tool

# Usage
``<bin> -help``

Keep in mind to paste all your proxies into the file called `proxies.txt`. Make sure all the proxies are valid and working ones, as this script is not checking for any proxy validity. Be sure to include **HTTP/HTTPS proxies only**.

# Build
Get your self some `Go` and afterwards you can compile and get a binary using `go build`
